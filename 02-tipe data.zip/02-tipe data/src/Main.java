public class Main {
    public static void main(String[] args) {
       
        
        //tipe data dalam java
        //interger, byte, short, long, double, float, char, blooean

        //integer (satuan)
        int a = 12;
        System.out.println("=====INTEGER=====");
        System.out.println("Nilai Integer Var a : " + a);
        System.out.println("Nilai Max : " + Integer.MAX_VALUE);
        System.out.println("Nilai Min : " + Integer.MIN_VALUE);
        System.out.println("Besar Size Integer : " + Integer.SIZE + "bit");

        //short
        short b = 13;
        System.out.println("=====SHORT=====");
        System.out.println("Nilai Short var b :" + b);
        System.out.println("Nilai Max : " + Short.MAX_VALUE);
        System.out.println("Nilai Min : " + Short.MIN_VALUE);
        System.out.println("Besar Size Integer : " + Short.SIZE);

        //float
        float c = 14;
        System.out.println("=====FLOAT=====");
        System.out.println("Nilai Float var c :" + c);
        System.out.println("Nilai Max : " + Float.MAX_VALUE);
        System.out.println("Nilai Min : " + Float.MIN_VALUE);
        System.out.println("Besar Size Float : " + Float.SIZE + "bit");

        //char
        char d = 'z';
        System.out.println("=====CHAR=====");
        System.out.println("Nilai Char var d :" + d);
        System.out.println("Besar Size Char : " + Character.SIZE);

        //boolean 
        boolean e = true;
        System.out.println("=====BLOOLEAN=====");
        System.out.println("Nilai Boolean var e :" + e);
        System.out.println("Nilai e : " + Boolean.TRUE);
        System.out.println("Nilai e :" + Boolean.FALSE);


        


        
        
    } 
}
